<?php if(!defined('FW')) die('forbidden');

$cfg = array(

    'page_builder' => array(
        'title' => __('Case Study With Filter', 'unyson'), 
        'tab'   => __('Content Elements', 'FW'),
        
    ),

);

