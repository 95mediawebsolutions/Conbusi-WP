<?php

include( fw()->extensions->get( 'portfolio' )->locate_view_path( 'archive' ) );