<?php if(!defined('FW')) die('forbidden');

$options = array(
    'section_heading' => array(
        'Label' => __('Heading','unyson'),
        'type'  => 'text'
    ),

    'custom_class' => array(
        'Label' => __('Custom Class','unyson'),
        'type'  => 'text'
    )
);