<?php if(!defined('FW')) die('forbidden');

$cfg = array(

    'page_builder' => array(
        'title' => __('Counter Area', 'unyson'), 
        'tab'   => __('Content Elements', 'FW'),
        
    ),

);

