<?php if(!defined('FW')) die('forbidden');

$cfg = array(

    'page_builder' => array(
        'title' => __('Icon With Text', 'unyson'), 
        'tab'   => __('Content Elements', 'FW'),
        
    ),

);

