<?php if (!defined('FW')) die('Forbidden');
$cfg['multimedia_types'] = array('image','video');
//$cfg['multimedia_types'] = array('image');
