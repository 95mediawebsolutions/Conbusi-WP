<?php if (!defined('FW')) die('Forbidden'); ?>
<p>View C content</p>
