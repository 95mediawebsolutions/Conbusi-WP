<?php if(!defined('FW')) die('forbidden');

$cfg = array(

    'page_builder' => array(
        'title' => __('Testimonal', 'unyson'), 
        'tab'   => __('Content Elements', 'FW'),
    ),

);

