<?php if (!defined('FW')) die('Forbidden');
$options = array(
	'subtitle' => array(
		'type' => 'text',
		'label' => __('Subtitle', 'unyson'),
		'value' => '',
		'desc' => __( 'Choose a subtitle for your slide.', 'unyson' )
	)
);

