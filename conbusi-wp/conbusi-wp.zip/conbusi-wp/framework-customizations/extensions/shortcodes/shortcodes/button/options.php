<?php if(!defined('FW')) die('forbidden');

$options = array(

     'button_label' => array(
        'label' => __('Enter text for button here', 'unyson'),
        'type' => 'text'
    ),

     'button_url' => array(
        'label' => __('Enter button url', 'unyson'),
        'type' => 'text'
    ),
    

    'custom_class' => array(
        'label' => __('Custom Class', 'unyson'),
        'type' => 'text'
    ),
);

