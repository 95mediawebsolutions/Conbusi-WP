This is an example of a shortcode integrated with the page builder.

The shortcode is as simple as it can be, it only has a config and a view file, no options, static (besides the builder icon) and class file.
